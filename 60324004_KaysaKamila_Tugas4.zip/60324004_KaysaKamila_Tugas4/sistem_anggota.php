<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistem Anggota</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<?php
require_once 'functions_anggota.php';

$anggota_list = [
    ["id"=>"AGT-001","nama"=>"Budi","status"=>"Aktif","total_pinjaman"=>5],
    ["id"=>"AGT-002","nama"=>"Siti","status"=>"Aktif","total_pinjaman"=>8],
    ["id"=>"AGT-003","nama"=>"Andi","status"=>"Non-Aktif","total_pinjaman"=>2],
    ["id"=>"AGT-004","nama"=>"Rina","status"=>"Aktif","total_pinjaman"=>10],
    ["id"=>"AGT-005","nama"=>"Dewi","status"=>"Non-Aktif","total_pinjaman"=>4]
];

$total = hitung_total_anggota($anggota_list);
$aktif = hitung_anggota_aktif($anggota_list);
$rata = hitung_rata_rata_pinjaman($anggota_list);
$teraktif = cari_anggota_teraktif($anggota_list);
?>

<div class="container mt-5">
    <h1 class="mb-4">Sistem Anggota Perpustakaan</h1>

    <div class="row mb-4">
        <div class="col-md-4"><div class="card p-3">Total: <?php echo $total; ?></div></div>
        <div class="col-md-4"><div class="card p-3">Aktif: <?php echo $aktif; ?></div></div>
        <div class="col-md-4"><div class="card p-3">Rata-rata: <?php echo number_format($rata,1); ?></div></div>
    </div>

    <div class="card">
        <div class="card-header bg-success text-white">Anggota Teraktif</div>
        <div class="card-body">
            <?php echo $teraktif["nama"]; ?> - <?php echo $teraktif["total_pinjaman"]; ?> pinjaman
        </div>
    </div>
</div>
</body>
</html>