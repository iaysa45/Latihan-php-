<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Array Anggota</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h1 class="mb-4">Data Anggota Perpustakaan</h1>

    <?php
    $anggota_list = [
        ["id"=>"AGT-001","nama"=>"Budi Santoso","email"=>"budi@email.com","telepon"=>"081234567890","alamat"=>"Jakarta","tanggal_daftar"=>"2024-01-15","status"=>"Aktif","total_pinjaman"=>5],
        ["id"=>"AGT-002","nama"=>"Siti Aminah","email"=>"siti@email.com","telepon"=>"081234567891","alamat"=>"Bandung","tanggal_daftar"=>"2024-02-10","status"=>"Aktif","total_pinjaman"=>8],
        ["id"=>"AGT-003","nama"=>"Andi Saputra","email"=>"andi@email.com","telepon"=>"081234567892","alamat"=>"Semarang","tanggal_daftar"=>"2024-03-05","status"=>"Non-Aktif","total_pinjaman"=>2],
        ["id"=>"AGT-004","nama"=>"Rina Putri","email"=>"rina@email.com","telepon"=>"081234567893","alamat"=>"Surabaya","tanggal_daftar"=>"2024-01-20","status"=>"Aktif","total_pinjaman"=>10],
        ["id"=>"AGT-005","nama"=>"Dewi Lestari","email"=>"dewi@email.com","telepon"=>"081234567894","alamat"=>"Yogyakarta","tanggal_daftar"=>"2024-04-01","status"=>"Non-Aktif","total_pinjaman"=>4]
    ];

    $total_anggota = count($anggota_list);
    $aktif = 0;
    $nonaktif = 0;
    $total_pinjaman = 0;
    $teraktif = $anggota_list[0];

    foreach ($anggota_list as $anggota) {
        if ($anggota["status"] == "Aktif") {
            $aktif++;
        } else {
            $nonaktif++;
        }

        $total_pinjaman += $anggota["total_pinjaman"];

        if ($anggota["total_pinjaman"] > $teraktif["total_pinjaman"]) {
            $teraktif = $anggota;
        }
    }

    $rata = $total_pinjaman / $total_anggota;
    ?>

    <div class="row mb-4">
        <div class="col-md-3"><div class="card p-3">Total: <?php echo $total_anggota; ?></div></div>
        <div class="col-md-3"><div class="card p-3">Aktif: <?php echo $aktif; ?></div></div>
        <div class="col-md-3"><div class="card p-3">Non-Aktif: <?php echo $nonaktif; ?></div></div>
        <div class="col-md-3"><div class="card p-3">Rata-rata: <?php echo number_format($rata,1); ?></div></div>
    </div>

    <div class="alert alert-success">
        Anggota Teraktif: <strong><?php echo $teraktif["nama"]; ?></strong>
    </div>

    <table class="table table-bordered">
        <thead class="table-dark">
            <tr>
                <th>ID</th>
                <th>Nama</th>
                <th>Email</th>
                <th>Status</th>
                <th>Total Pinjaman</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($anggota_list as $anggota) { ?>
            <tr>
                <td><?php echo $anggota["id"]; ?></td>
                <td><?php echo $anggota["nama"]; ?></td>
                <td><?php echo $anggota["email"]; ?></td>
                <td><?php echo $anggota["status"]; ?></td>
                <td><?php echo $anggota["total_pinjaman"]; ?></td>
            </tr>
            <?php } ?>
        </tbody>
    </table>
</div>
</body>
</html>